from django.apps import AppConfig


class RendermarkdownConfig(AppConfig):
    name = 'rendermarkdown'
