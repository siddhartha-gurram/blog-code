from django.apps import AppConfig


class BillionsConfig(AppConfig):
    name = 'billions'
